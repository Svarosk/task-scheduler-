import React, { useState } from 'react';
import axios from 'axios';

const TaskForm = ({ refresh }) => {
  const [title, setTitle] = useState('');
  const [deadline, setDeadline] = useState('');
  const [priority, setPriority] = useState('Low');

  const addTask = async () => {
    await axios.post('http://localhost:5000/api/tasks', {
      title,
      deadline,
      priority,
      isCompleted: false,
    });
    setTitle('');
    setDeadline('');
    setPriority('Low');
    refresh();
  };

  return (
    <div>
      <input placeholder="Title" value={title} onChange={e => setTitle(e.target.value)} />
      <input type="datetime-local" value={deadline} onChange={e => setDeadline(e.target.value)} />
      <select value={priority} onChange={e => setPriority(e.target.value)}>
        <option>Low</option>
        <option>Medium</option>
        <option>High</option>
      </select>
      <button onClick={addTask}>Add Task</button>
    </div>
  );
};

export default TaskForm;