import React from 'react';
import axios from 'axios';

const TaskList = ({ tasks, refresh }) => {
  const toggleComplete = async (task) => {
    await axios.put(`http://localhost:5000/api/tasks/${task._id}`, {
      ...task,
      isCompleted: !task.isCompleted,
    });
    refresh();
  };

  const deleteTask = async (id) => {
    await axios.delete(`http://localhost:5000/api/tasks/${id}`);
    refresh();
  };

  return (
    <ul>
      {tasks.map(task => (
        <li key={task._id}>
          <strong>{task.title}</strong> — {new Date(task.deadline).toLocaleString()} [{task.priority}]
          <button onClick={() => toggleComplete(task)}>
            {task.isCompleted ? 'Undo' : 'Complete'}
          </button>
          <button onClick={() => deleteTask(task._id)}>Delete</button>
        </li>
      ))}
    </ul>
  );
};

export default TaskList;