const mongoose = require('mongoose');

const taskSchema = new mongoose.Schema({
  title: String,
  deadline: Date,
  priority: String,
  isCompleted: Boolean,
});

module.exports = mongoose.model('Task', taskSchema);